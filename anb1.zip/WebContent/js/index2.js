/*
 @ElmahdiMahmoud
 May 19, 2013
*/
$(".view a").on('click', function(){
    $('.products ul').toggleClass('list');
    return false;
});